list_platform = []

list_medium = []

list_source = []
